using Dislin

ctit = "Symbols"

Dislin.setpag("da4p")
Dislin.metafl("cons")

Dislin.disini()
Dislin.pagera()
Dislin.hwfont()
Dislin.paghdr("H. Michels (", ")", 2, 0)

Dislin.height(60)
nl = Dislin.nlmess(ctit)
Dislin.messag(ctit, div(2100 - nl, 2), 200)

Dislin.height(50)
Dislin.hsymbl(120)

ny = 150
nxp = 0 
for j = 1:24
  i = j - 1
  x = j - 1.0
  if((i % 4) == 0)
    ny  = ny + 400
    nxp = 550
  else 
    nxp = nxp + 350
  end
  nl = Dislin.nlnumb(x, -1)
  Dislin.number(x, -1, nxp - div(nl, 2), ny + 150)
  Dislin.symbol(i, nxp, ny)
end
Dislin.disfin()

